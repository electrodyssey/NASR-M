/**
 * \file
 *
 * \brief Created to add Application definitions
 *
 * Copyright (c) 2016 Atmel Corporation. All rights reserved.
 *
 * \asf_license_start
 *
 * \page License
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 * 1. Redistributions of source code must retain the above copyright notice,
 *    this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright notice,
 *    this list of conditions and the following disclaimer in the documentation
 *    and/or other materials provided with the distribution.
 *
 * 3. The name of Atmel may not be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * 4. This software may only be redistributed and used in connection with an
 *    Atmel microcontroller product.
 *
 * THIS SOFTWARE IS PROVIDED BY ATMEL "AS IS" AND ANY EXPRESS OR IMPLIED
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
 * MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT ARE
 * EXPRESSLY AND SPECIFICALLY DISCLAIMED. IN NO EVENT SHALL ATMEL BE LIABLE FOR
 * ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
 * OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
 * ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 *
 * \asf_license_stop
 *
 */

#ifndef APP_DEF_H
#define APP_DEF_H

/*
 * This file includes Application definitions.
 * 
 */
typedef void (*fpJumpHandler)(void);

#define U32_USB_CDC_USER_APP_SW_RELEASE_MAJOR_VERSION		((U32)0x2)
#define U32_USB_CDC_USER_APP_SW_RELEASE_MINOR_VERSION		((U32)0x1)
#define U32_BOOT_LOADER_APPLICATION_START_ADDRESS			((U32)0x00400000)
#define U32_BOOT_LOADER_APPLICATION_ALLOCATED_SIZE			((U32)0x0000C000)
#define U32_USER_APPLICATION_START_ADDRESS					((U32)0x0040C000)
#define U32_USER_APPLICATION_ALLOCATED_SIZE					((U32)0x001F4000)
#define CUSTOM_DEBUG(x)										
#define U16_USB_CDC_MAX_DATA_SIZE							((U16)540)
#define U16_USB_DEVICE_CDC_MAX_DATA_SIZE					((U16)20)
#define U8_HASH_TAG_DATA_SIZE								((U8)5)
#define NO_OF_ELEMENTS_IN_ARRAY(array)						sizeof(array)/sizeof(array[0])							
#define U32_TIME_BEFORE_WDT_RESET_MSEC						((U32)3000)		/* Watchdog reset time */

typedef struct
{
	U8 u8FrameIdentifier;
	U8 u8Cmd;
	U8 au8Data[U16_USB_CDC_MAX_DATA_SIZE];
}TS_USB_CDC_FRAME;

typedef struct
{
	U8 u8FrameIdentifier;
	U8 u8Cmd;
	U8 au8Data[U16_USB_DEVICE_CDC_MAX_DATA_SIZE];
}TS_USB_DEVICE_CDC_FRAME;

typedef struct
{
	U32 u32ApplicationVersion_Major;
	U32 u32ApplicationVersion_Minor;
	fpJumpHandler fpApplicationJumpHandler;
	U32 u32BootApplicationStartAddress;
	U32 u32BootApplicationAllocationSize;
	U32 u32UserApplicationStartAddress;
	U32 u32UserApplicationAllocationSize;
}TS_ApplicationData;

typedef union
{
	U32 au32ApplicationData[32];
	TS_ApplicationData sApplicationData;
}TU_ApplicationData;

typedef struct
{
	U32 u32SHA_1PaddingBytes[16];
}TS_SHA_Padding;

typedef struct
{
	U32 au32ApplicationHashTag[16];
}TS_SHA_Digest;

typedef struct
{
	TU_ApplicationData uApplicationData;
	TS_SHA_Padding sSHA_Padding;
	TS_SHA_Digest sSHA_Digest;
}TS_ApplicationFooter;

enum
{
	eBOOTLOADER_ENTER_BOOT_MODE = 0xB0,
	eBOOTLOADER_RESET_DEVICE,
	eBOOTLOADER_QUERY_DEVICE_MODE,
};

enum
{
	eBOOTLOADER_DATA_START_INDEX
};


/* Function Prototypes main.c*/
void JumpToBootloaderHandler(void);
TS_ApplicationData* P_GetApplicationData(void);
void ResetDevice(void);

/* Function Prototypes AppCDC.c*/
void USB_RecvHandler(void);
void ProcessCDC_Msg(void);
void PlaceRequestToXmitOnCDC(TS_USB_DEVICE_CDC_FRAME* psUSB_DeviceCDC_Data, U16 u16DataSize);
Bool B_EnableUSB_CDC_Interface(U8 u8Port);
void DisableUSB_CDC_Interface(U8 u8Port);
#endif // APP_DEF_H
