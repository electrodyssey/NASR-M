/**
 * \file
 *
 * \brief Empty user application template
 *
 */

/**
 * \mainpage User Application template doxygen documentation
 *
 * \par Empty user application template
 *
 * Bare minimum empty user application template
 *
 * \par Content
 *
 * -# Include the ASF header files (through asf.h)
 * -# "Insert system clock initialization code here" comment
 * -# Minimal main function that starts with a call to board_init()
 * -# "Insert application code here" comment
 *
 */

/*
 * Include header files for all drivers that have been imported from
 * Atmel Software Framework (ASF).
 */
/*
 * Support and FAQ: visit <a href="http://www.atmel.com/design-support/">Atmel Support</a>
 */
#include <asf.h>
#include "AppDef.h"

/** static function prototypes */
static void ConfigureConsole(void);

/** Creating a dummy section to fill unused flash with 0xFF.. */
const U8 u8Dummy __attribute__ ((section(".fill"))) = 0xFF;

__attribute__ ((section(".ApplicationFooterData")))
const TS_ApplicationFooter sUserApplicationFooter =
{
	{
		U32_USB_CDC_USER_APP_SW_RELEASE_MAJOR_VERSION,
		U32_USB_CDC_USER_APP_SW_RELEASE_MINOR_VERSION,
		NULL,
		U32_BOOT_LOADER_APPLICATION_START_ADDRESS,
		U32_BOOT_LOADER_APPLICATION_ALLOCATED_SIZE,
		U32_USER_APPLICATION_START_ADDRESS,
		U32_USER_APPLICATION_ALLOCATED_SIZE,
	},
	{0},
	{0},
};

int main (void)
{
	/** Insert system clock initialization code here (sysclk_init()). */
	sysclk_init();
	board_init();

	/** Insert application code here, after the board has been initialized. */
	
	/** Initialize console to view log messages*/
	ConfigureConsole();
	
	printf("\r\nSW Version: Major:%02X Minor:%02X\r\n",
		sUserApplicationFooter.uApplicationData.sApplicationData.u32ApplicationVersion_Major,
		sUserApplicationFooter.uApplicationData.sApplicationData.u32ApplicationVersion_Minor);

	/** Start USB stack to authorize VBus monitoring */
	printf("Starting UDC\r\n");
	udc_start();

	while(1)
	{
		ProcessCDC_Msg();
	}
}
/**
 * \brief Configure UART console.
 */
static void ConfigureConsole(void)
{
	const usart_serial_options_t uart_serial_options = {
		.baudrate = CONF_UART_BAUDRATE,
#ifdef CONF_UART_CHAR_LENGTH
		.charlength = CONF_UART_CHAR_LENGTH,
#endif
		.paritytype = CONF_UART_PARITY,
#ifdef CONF_UART_STOP_BITS
		.stopbits = CONF_UART_STOP_BITS,
#endif
	};

	/* Configure console UART. */
	sysclk_enable_peripheral_clock(CONSOLE_UART_ID);
	stdio_serial_init(CONF_UART, &uart_serial_options);
}

/**
 * \brief This function enables calling application to jump to Boot loader.
 */
void JumpToBootloaderHandler(void)
{
	
	TS_ApplicationData* pCurrentApplicationData;
	TS_ApplicationData* pBootApplicationData;
	volatile fpJumpHandler fpBootloaderJumpHandler;
	
	/** Get Application header data*/
	pCurrentApplicationData = P_GetApplicationData();
	
	/** Get Bootloader Application Data */
	pBootApplicationData = (TS_ApplicationData*)(pCurrentApplicationData->u32BootApplicationStartAddress +
		pCurrentApplicationData->u32BootApplicationAllocationSize - sizeof(TS_ApplicationFooter));
	
	fpBootloaderJumpHandler = pBootApplicationData->fpApplicationJumpHandler;
	
	/** Set to remain in Boot loader */
	(*fpBootloaderJumpHandler)();
}

/**
 * \brief This function Returns Application data from Footer.
 */
TS_ApplicationData* P_GetApplicationData(void)
{
	return(&(sUserApplicationFooter.uApplicationData.sApplicationData));
}

/**
 * \brief This function Resets device using RSTC module
 */
void ResetDevice(void)
{
	/** Wait for device reset.... Watchdog is configured to reset device */
	printf("Reset Request Received\r\n");
	/** Wait for Message transmission */
	while (!uart_is_tx_buf_empty(CONSOLE_UART));
			
	RSTC->RSTC_CR = 0xA5000000 | RSTC_CR_PROCRST;
	while(1);
}