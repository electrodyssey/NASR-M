/**
 * \mainpage User Application Doxygen documentation
 *
 * \file
 *
 * \brief This is main module of Boot loader Application
 *
 */

/*
 * Include header files for all drivers that have been imported from
 * Atmel Software Framework (ASF).
 */
/*
 * Support and FAQ: visit <a href="http://www.atmel.com/design-support/">Atmel Support</a>
 */
#include <asf.h>
#include <string.h>
#include "AppDef.h"

/** static function prototypes */
static void ConfigureConsole(void);
static void BootloaderJumpHandler(void);
static Bool B_IsItRequiredToStayInBootloader(void);
static Bool B_IsUserApplicationValid(void);
static void JumpToUserApplication(void);

/** Creating a dummy section to fill unused flash with 0xFF.. */
const U8 u8Dummy __attribute__ ((section(".fill"))) = 0xFF;

/** Creating section to store Application Footer Data... This data is critical as Bootloader uses this before jumping here */
__attribute__ ((section(".ApplicationFooterData")))
const TS_ApplicationFooter sBootLoaderFooter = 
{
	{
		U32_USB_CDC_BOOTLOADER_SW_RELEASE_MAJOR_VERSION,
		U32_USB_CDC_BOOTLOADER_SW_RELEASE_MINOR_VERSION,
		BootloaderJumpHandler,
		U32_BOOT_LOADER_APPLICATION_START_ADDRESS,
		U32_BOOT_LOADER_APPLICATION_ALLOCATED_SIZE,
		U32_USER_APPLICATION_START_ADDRESS,
		U32_USER_APPLICATION_ALLOCATED_SIZE,
	},
	{0},
	{0},
};

__attribute__ ((section(".JumpSignatureData")))
static U8 mau8JumpSignature[32];

COMPILER_ALIGNED(128)
U32 u32SHA_1_Digest[5] = {0,0,0,0,0};

/**
 * \brief Main function of the Application.
 * \param 
 */
int main (void)
{
	/** Insert system clock initialization code here (sysclk_init()). */
	sysclk_init();
	board_init();

	/** Insert application code here, after the board has been initialized. */
	
	/** Initialize console to view log messages*/
	ConfigureConsole();
	
	printf("\r\nSW Version: Major:%02X Minor:%02X\r\n", 
		sBootLoaderFooter.uApplicationData.sApplicationData.u32ApplicationVersion_Major,
		sBootLoaderFooter.uApplicationData.sApplicationData.u32ApplicationVersion_Minor);

	/** Check for valid User Application existence on the flash */
	if(B_IsItRequiredToStayInBootloader())
	{
		/** Remain in Boot loader, don't jump anywhere */
	}
	else
	{
		/** Check validity of existing User Application */
		if(B_IsUserApplicationValid())
		{
			/** Jump to User Application as it is valid */
			JumpToUserApplication();
		}
		else
		{
			/** Remain in Boot loader, as User Application seems to be bad */
		}
	}

	InitFlashWaitStates();
	
	/** Start USB stack to authorize VBus monitoring */
	printf("Starting UDC\r\n");
	udc_start();

	while(1)
	{
		ProcessCDC_Msg();
	}
}

/**
 * \brief This function verifies User Application
 */
static Bool B_IsUserApplicationValid(void)
{
	TS_ApplicationData* pCurrentApplicationData;
	TS_ApplicationData* pUserApplicationData;
	U32 u32DigestLocation;
	Bool bUserApplicationValid = false;
	
	/** Get Application header data*/
	pCurrentApplicationData = P_GetApplicationData();
	
	pUserApplicationData = (TS_ApplicationData*)(pCurrentApplicationData->u32UserApplicationStartAddress +
		pCurrentApplicationData->u32UserApplicationAllocationSize - sizeof(TS_ApplicationFooter));
	
	/** Check if Flash information in Application and Boot loader Matches */
	if((pUserApplicationData->u32UserApplicationStartAddress == pCurrentApplicationData->u32UserApplicationStartAddress) && 
		(pUserApplicationData->u32UserApplicationAllocationSize == pCurrentApplicationData->u32UserApplicationAllocationSize) && 
		(pUserApplicationData->u32BootApplicationStartAddress == pCurrentApplicationData->u32BootApplicationStartAddress) &&
		(pUserApplicationData->u32BootApplicationAllocationSize == pCurrentApplicationData->u32BootApplicationAllocationSize))
	{
		u32DigestLocation = pUserApplicationData->u32UserApplicationStartAddress + 
			pUserApplicationData->u32UserApplicationAllocationSize - sizeof(TS_SHA_Digest);
	
		InitICM_Module();
		CalculateICM(pUserApplicationData->u32UserApplicationStartAddress, 
			(pUserApplicationData->u32UserApplicationAllocationSize - sizeof(TS_SHA_Digest)), (U32*)u32SHA_1_Digest);
		
		/** Check Integrity of User Application*/
		if(!memcmp((const _PTR)u32DigestLocation, u32SHA_1_Digest, sizeof(u32SHA_1_Digest)))
		{
			/** Indicate User Application is valid*/
			bUserApplicationValid = true;
		}
		else
		{
			/** Do Nothing */
		}
	}
	else
	{
		/** Do Nothing */
	}
	
	return(bUserApplicationValid);
}

/**
 * \brief This function checks if source application requested to stay in Boot loader
 */
static Bool B_IsItRequiredToStayInBootloader(void)
{
	Bool bStayInBootLoader = true;
	
	/** Check if Jump signature updated to remain in Boot loader */
	if(strcmp((const char*)mau8JumpSignature, "StayInBootLoader"))
	{
		/** Source application not requested to remain in Boot loader */
		bStayInBootLoader = false;
	}
	
	/** Clear this instruction to avoid reusing it*/
	strcpy(mau8JumpSignature, "InvalidateThisData");

	return(bStayInBootLoader);
}

/**
 * \brief Configure UART console.
 */
static void ConfigureConsole(void)
{
	const usart_serial_options_t uart_serial_options = 
	{
		.baudrate = CONF_UART_BAUDRATE,
		#ifdef CONF_UART_CHAR_LENGTH
			.charlength = CONF_UART_CHAR_LENGTH,
		#endif
		.paritytype = CONF_UART_PARITY,
		#ifdef CONF_UART_STOP_BITS
			.stopbits = CONF_UART_STOP_BITS,
		#endif
	};

	/** Configure console UART with CONF_UART_BAUDRATE-CONF_UART_CHAR_LENGTH-CONF_UART_PARITY-CONF_UART_STOP_BITS. */
	sysclk_enable_peripheral_clock(CONSOLE_UART_ID);
	stdio_serial_init(CONF_UART, &uart_serial_options);
}

/**
 * \brief This function enables calling application to jump to Boot loader by updating Jump Signature.
 */
static void BootloaderJumpHandler(void)
{
	/** Update Signature to indicate Boot loader */
	strcpy(mau8JumpSignature, "StayInBootLoader");
}

/**
 * \brief This function jumps to User Application after taking necessary steps in Boot loader.
 */
static void JumpToUserApplication(void)
{
	TS_ApplicationData* pCurrentApplicationData;
	TS_ApplicationData* pUserApplicationData;
	U32 u32StackPointerValue;
	fpJumpHandler fpApplicationResetHandler;
		
	/** Release Resources before jumping to User Application */
	udc_stop();
	sysclk_disable_peripheral_clock(CONSOLE_UART_ID);
	
	/** Disable interrupts */
	__disable_irq();
	
	/** Get Application header data*/
	pCurrentApplicationData = P_GetApplicationData();
	
	pUserApplicationData = (TS_ApplicationData*)(pCurrentApplicationData->u32UserApplicationStartAddress +
		pCurrentApplicationData->u32UserApplicationAllocationSize - sizeof(TS_ApplicationFooter));
	
	/** Barriers */
	__DSB();
	__ISB();

	/** Update vector table */
	SCB->VTOR = pUserApplicationData->u32UserApplicationStartAddress & SCB_VTOR_TBLOFF_Msk;
	
	/** Barriers */
	__DSB();
	__ISB();

	/** Enable interrupts */
	__enable_irq();

	/** Update stack pointer */
	u32StackPointerValue = (U32)(*(uint32_t *)(pUserApplicationData->u32UserApplicationStartAddress));
	__set_MSP(u32StackPointerValue);
	
	/** Call Application reset handler */
	fpApplicationResetHandler = (fpJumpHandler)(*((U32*)(pUserApplicationData->u32UserApplicationStartAddress + 4)));
	(*fpApplicationResetHandler)();
}

/**
 * \brief This function Returns Application data from Footer.
 */
TS_ApplicationData* P_GetApplicationData(void)
{
	return(&(sBootLoaderFooter.uApplicationData.sApplicationData));
}

/**
 * \brief This function Resets device using RSTC module
 */
void ResetDevice(void)
{
	/** Wait for device reset.... Watchdog is configured to reset device */
	printf("Reset Request Received\r\n");
	/** Wait for Message transmission */
	while (!uart_is_tx_buf_empty(CONSOLE_UART));
			
	RSTC->RSTC_CR = 0xA5000000 | RSTC_CR_PROCRST;
	while(1);
}