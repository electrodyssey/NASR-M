/**
 *
 * \file
 *
 * \brief This module takes care of Decryption and Integrity check associated with this Application
 *
 */

/*
 * Include header files for all drivers that have been imported from
 * Atmel Software Framework (ASF).
 */
/*
 * Support and FAQ: visit <a href="http://www.atmel.com/design-support/">Atmel Support</a>
 */
#include <asf.h>
#include <string.h>
#include "AppDef.h"

/** Global/Static Variables*/
/* Region descriptor in main list */
COMPILER_ALIGNED(64)
struct icm_region_descriptor_main_list reg_descriptor;

COMPILER_ALIGNED(4)
/* Region descriptor in secondary list */
struct icm_region_descriptor_sec_list reg_descriptor_sec;

static U32 mau32AES_Key[4];					/** Key size is 128-bits */
static U32 mau32AES_Vector[4];				/** Vector size is 128-bits */
static U32 mau32AES_DecryptedData[128];		/** Decrypt data size 512 bytes */
struct aes_config ecb_cfg;

/** Static function Prototypes */
static void ReverseEndian(void* pData, U16 u16Count);

static const U32 mau32AES_KeyList[4][4] = 
{
	0x01234567, 0x89ABCDEF, 0x89ABCDEF, 0x01234567,	/** Key1 */
	0x89ABCDEF, 0x89ABCDEF, 0x01234567, 0x01234567, /** Key2 */
	0x89ABCDEF, 0x01234567, 0x01234567, 0x89ABCDEF, /** Key3 */
	0x89ABCDEF, 0x01234567, 0x89ABCDEF, 0x01234567,	/** Key4 */ 
};

static const U32 mau32AES_VectorList[4][4] =
{
	0x89ABCDEF, 0x01234567, 0x89ABCDEF, 0x01234567, /** Vector1 */
	0x89ABCDEF, 0x01234567, 0x01234567, 0x89ABCDEF, /** Vector2 */
	0x89ABCDEF, 0x89ABCDEF, 0x01234567, 0x01234567, /** Vector3 */
	0x01234567, 0x89ABCDEF, 0x89ABCDEF, 0x01234567, /** Vector4 */
};

/**
 * \brief This function initializes ICM Module
 * \param[in]
 * \param[out]
 */
void InitICM_Module(void)
{
	struct icm_config icm_cfg;
	
	/** Initialize ICM Config params */
	icm_cfg.is_write_back= false;
	icm_cfg.is_dis_end_mon = false;
	icm_cfg.is_sec_list_branch = true;
	icm_cfg.bbc = 0;
	icm_cfg.is_auto_mode = false;
	icm_cfg.is_dual_buf = false;
	icm_cfg.is_user_hash = false;
	icm_cfg.ualgo = ICM_SHA_1;
	icm_cfg.hash_area_val = 0;
	icm_cfg.des_area_val = 0;
	
	/** Init ICM Module with configured data*/
	icm_init(ICM, &icm_cfg);
}

/**
 * \brief This function executes SHA-1 algorithm and updates result to output buffer
 * \param[in] U32 u32StartAddress
 * \param[in] U32 u32Size
 * \param[inout] U32* pu32Result
 */
void CalculateICM(U32 u32StartAddress, U32 u32Size, U32* pu32Result)
{
	reg_descriptor.start_addr = u32StartAddress;
	reg_descriptor.cfg.is_compare_mode = false;
	reg_descriptor.cfg.is_wrap = false;
	reg_descriptor.cfg.is_end_mon = true;
	reg_descriptor.cfg.reg_hash_int_en = false;
	reg_descriptor.cfg.dig_mis_int_en = false;
	reg_descriptor.cfg.bus_err_int_en = false;
	reg_descriptor.cfg.wrap_con_int_en = false;
	reg_descriptor.cfg.ebit_con_int_en = false;
	reg_descriptor.cfg.status_upt_con_int_en = false;
	reg_descriptor.cfg.is_pro_dly = false;
	reg_descriptor.cfg.mem_reg_val = 0;
	reg_descriptor.cfg.algo = ICM_SHA_1;
	reg_descriptor.tran_size = (u32Size/64) - 1;
	reg_descriptor.next_addr = 0;
	
	/** Set region descriptor start address */
	icm_set_reg_des_addr(ICM, (U32)&reg_descriptor);
	icm_set_hash_area_addr(ICM, (U32)pu32Result);
		
	/** Enable ICM */
	icm_enable(ICM);
		
	/** Check region hash is completed */
	while(!(icm_get_interrupt_status(ICM) & 1));
}

/**
 * \brief This function updates AES Key... It reverses endian of the received input before copying to buffer
 * \param[in] U8 u8KeyIndex
 */
void UpdateAES_Key(U8 u8KeyIndex)
{
	if(u8KeyIndex < sizeof(mau32AES_KeyList) / sizeof(mau32AES_Key))
	{
		mau32AES_Key[0] = mau32AES_KeyList[u8KeyIndex][0];
		mau32AES_Key[1] = mau32AES_KeyList[u8KeyIndex][1];
		mau32AES_Key[2] = mau32AES_KeyList[u8KeyIndex][2];
		mau32AES_Key[3] = mau32AES_KeyList[u8KeyIndex][3];
		ReverseEndian((void*)mau32AES_Key, 16);
	}
	else
	{
		CUSTOM_DEBUG(printf("Key Index is greater than available Keys"));
	}
}

/**
 * \brief This function updates AES Vector... It reverses endian of the received input before copying to buffer
 * \param[in] U8 u8IV_Index
 */
void UpdateAES_Vector(U8 u8IV_Index)
{
	if(u8IV_Index < sizeof(mau32AES_VectorList) / sizeof(mau32AES_Vector))
	{
		mau32AES_Vector[0] = mau32AES_VectorList[u8IV_Index][0];
		mau32AES_Vector[1] = mau32AES_VectorList[u8IV_Index][1];
		mau32AES_Vector[2] = mau32AES_VectorList[u8IV_Index][2];
		mau32AES_Vector[3] = mau32AES_VectorList[u8IV_Index][3];
		ReverseEndian((void*)mau32AES_Vector, 16);
	}
	else
	{
		CUSTOM_DEBUG(printf("Vector Index is greater than available Vectors"));
	}
}

/**
 * \brief This function reverses Endian of the received data
 * \param[inout] void* pData
 * \param[in] U16 u16Count
 */
static void ReverseEndian(void* pData, U16 u16Count)
{
	U16 u16Index;
	U32* p32InputData = (U32*)pData;
	
	for(u16Index = 0; u16Index < (u16Count/sizeof(U32)); u16Index++)
	{
		p32InputData[u16Index] = __REV(p32InputData[u16Index]);
	}
}
/**
 * \brief This function Decrypts input data of given size
 * \param[in] void* pData
 * \param[in] U16 u16DataSize
 * \param[OUT] U8* mau32AES_DecrptedData
 */
U8* P_DecryptReceivedPageData(void* pData, U16 u16DataSize)
{
	U16 u16DataIndex;
	U32* pAES_Input = pData;
	U32* pAES_Output = mau32AES_DecryptedData;
	
	/** Enable peripheral clock. */
	aes_reset(AES);
	aes_enable();
	
	/** Configure the AES in CBC mode. */
	ecb_cfg.encrypt_mode = AES_DECRYPTION;
	ecb_cfg.key_size = AES_KEY_SIZE_128 ;
	ecb_cfg.start_mode = AES_AUTO_START ;
	ecb_cfg.opmode = AES_CBC_MODE;
	ecb_cfg.cfb_size = AES_CFB_SIZE_128;
	ecb_cfg.lod = false;
	aes_set_config(AES, &ecb_cfg);
	aes_write_key(AES, mau32AES_Key);
	AES->AES_IER |= 0x1;
	
	/** Update Init Vector. */
	aes_write_initvector(AES, mau32AES_Vector);

	/** Loop through for all data. */
	for(u16DataIndex=0; u16DataIndex < (u16DataSize/(4*4)); u16DataIndex++)
	{
		/** Feed in initial set of data. */
		aes_write_input_data(AES, pAES_Input);
		while(AES->AES_ISR == 0){}
		
		/** Read Decrypted data */
		aes_read_output_data(AES, pAES_Output);
		pAES_Input += 4;
		pAES_Output += 4;
	}

	return((U8*)mau32AES_DecryptedData);
}