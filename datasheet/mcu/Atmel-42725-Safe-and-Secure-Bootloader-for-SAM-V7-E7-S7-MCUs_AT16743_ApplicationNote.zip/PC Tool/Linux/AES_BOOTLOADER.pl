#---------------------------------------------------------------------------
#  packages and includes
#---------------------------------------------------------------------------
use strict;
use warnings;
if ($^O eq "MSWin32"){
	require Win32::SerialPort;
}
if ($^O eq "linux"){
	require Device::SerialPort;
}
use Tk;
use Tk::Optionmenu;
use Crypt::CBC;
use Digest::SHA1;
use Crypt::OpenSSL::AES;
use Tk::Bitmap;
use Tk::Dialog;
use Time::HiRes qw[gettimeofday tv_interval];
#************************************************************************************************Variable and declarations*************************************************************************


#---------------------------------------------------------------------------
#  GUI related variables
#---------------------------------------------------------------------------

my $mainwindow			= '';


#---------------------------------------------------------------------------
# Label variables  
#---------------------------------------------------------------------------
my $connection_warning_label	= '';
my $start_address_label = '';
my $select_conn_label   = '';
my $select_file_label   = '';
my $input_key_label		= '';
my $input_iv_label		= '';
my $dummy_label	= '';


#---------------------------------------------------------------------------
#  Drop down menu variable
#---------------------------------------------------------------------------
my $drop_down_menu		= '';

#---------------------------------------------------------------------------
#  button variables
#---------------------------------------------------------------------------
my $erase_button		= '';
my $open_file_button    = '';
my $program_button		= '';
my $encrypt_prog_button = '';
my $encrypt_save_button = '';

#---------------------------------------------------------------------------
#		Checkbutton variable  
#---------------------------------------------------------------------------
my $is_encrypted		= '';

#---------------------------------------------------------------------------
# Gui Input entry variables 
#---------------------------------------------------------------------------
my $input_file_entry	= '';
my $input_key			= '';
my $input_iv            = '';
my $start_address_entry = '';

#---------------------------------------------------------------------------
#  commands for the bootloader communication
#---------------------------------------------------------------------------
my $header 				= 'ff';
my $open   				= 'B0';
my $query_mode			= 'B2';
my $reset				= 'B1';
my $set_passcode 		= 'B3';
my $erase				= 'B4';
my $program				= 'B5';
my $program_2			= 'B6';

#---------------------------------------------------------------------------
# 	Response message 
#---------------------------------------------------------------------------
my $success_open		= pack("H6","ffb000");
my $success_open_application =  pack("H6","ffb001");
my $is_bootloader		= pack("H6","ffb200");
my $is_application		= pack("H6","ffb201");
my $success_set_key		= pack("H6","ffb300");
my $success_erase       = pack("H6","ffb400");
my $success_program     = pack("H6","ffb500");
my $success_program_2   = pack("H6","ffb600");

#---------------------------------------------------------------------------
#  Other variables
#---------------------------------------------------------------------------
my $user_warning_variable = '';
my $port				= '';
my $result				= '';
my $form_packet			= '';
my $input_file 			= '';
my $key 				= '';
my $iv  				= '';
my $device 				= '';
my $encrypted_input		= 0 ;
my $start_address 		= '40c000';
my $current_address 	= '';
my $in					= '';
my $filesize			= '';
my $stuff_byte_number	= '';
my $pad					= 'ff';
my $stuff				= '';
my $input_file_handle	= '';
my $flash_data			= '';
my $byte_count			= 0;
my $page_size			= 512;
my $cipher				= '';
my $output_file			= '';
my $receive_response_value	= '';
my $encrypted_data			= '01';
my $normal_data				= '00';
my $passcode				= '';
my $is_erased = 0;
my @key = qw/0123456789abcdef89abcdef01234567 89abcdef89abcdef0123456701234567 89abcdef012345670123456789abcdef 89abcdef0123456789abcdef01234567/;
my @iv = qw/89abcdef0123456789abcdef01234567 89abcdef012345670123456789abcdef 89abcdef89abcdef0123456701234567 0123456789abcdef89abcdef01234567/;
#---------------------------------------------------------------------------
#  Input and Output file type selection
#---------------------------------------------------------------------------

my $input_file_type = [
     ['Binary Files',       ['.bin', '.BIN']],
 ];
my $output_file_type = [
	['Binary file',      ['.bin', '.BIN' ] ],
     ['Text Files',       ['.txt', '.text']],
     ['All Files',        '*',             ],
 ];

#********************************************************************************************** Variable and declaration Ends *******************************************************************




#*********************************************************************************************** Main GUI ****************************************************************************************

#---------------------------------------------------------------------------
#  Main Window
#---------------------------------------------------------------------------

my $mw = MainWindow->new;
$mw->resizable( 0, 0 );
$mainwindow = $mw->Frame(-background => 'white')->pack(-ipadx => 50, -side => "left", -fill => "y");

#Labels ----------------------------------------------------------------------------
# Select the device label
$select_conn_label=$mainwindow->Label(
	-background => 'white',
	-text => 'Select COM port'
	)->grid(
	-row => 1,
	-sticky => "w",
	-column => 0
	);
#  Select file label
$select_file_label = $mainwindow->Label(
	-background => 'white',
	-text => 'Select File'
	)->grid(
	-row => 3,
	-column => 0
	);
#  Encryption key input label
$input_key_label = $mainwindow->Label(
	-background => 'white',
	-text => 'Passcode'
	)->grid(
	-row => 5,
	-column => 0
	);
# Start address label  
$start_address_label = $mainwindow->Label(
	-background => 'white',
	-text => 'Start Address'
	)->grid(
	-row => 9,
	-column => 0
	);

#  No device detected warning 
$connection_warning_label = $mainwindow->Label(
	-background => 'white',
	-foreground => 'Red',
	-textvariable => \$user_warning_variable
	)->grid(
	-row => 0,
	-column => 1,
	-columnspan => 2
	);
#  Input file address empty warning
$dummy_label = $mainwindow->Label(
	-background => 'white',
	-foreground => 'Red',
	)->grid(
	-row => 2,
	-column => 1,
	-columnspan => 2
	);
# Input key empty warning  
$dummy_label = $mainwindow->Label(
	-background => 'white',
	-foreground => 'Red',
	)->grid(
	-row => 4,
	-column => 1,
	-columnspan => 2
	);
#  Start address empty warning
$dummy_label = $mainwindow->Label(
	-background => 'white',
	-foreground => 'Red',
	)->grid(
	-row => 8,
	-column => 1,
	-columnspan => 2
	);

#Buttons ---------------------------------------------------------------------------
#  Enter Boot loader Button  
my $enter_button = $mainwindow->Button(
	-background => 'white',
	-text => 'Enter Bootloader',
	-command => sub {enter_bootloader()}
	)->grid(
	-row => 1 ,
	-column =>2
	);
#  Erase button  
$erase_button = $mainwindow->Button(
	-background => 'white',
	-text => 'Erase',
	-command => sub {erase()}
	)->grid(
	-row => 1 ,
	-column =>3
	);
#  File browse option
$open_file_button = $mainwindow->Button(
	-background => 'white',
	-text => 'Open File',
	-command => sub {open_file()}
	)->grid(
	-row => 3 ,
	-column =>2
	);
#  Program button
$program_button = $mainwindow->Button(
	-background => 'white',
	-text => 'Program',
	-command => sub {program()}
	)->grid(
	-row => 11,
	-column =>0
	);
#  encrypt and save button
$encrypt_save_button = $mainwindow->Button(
	-background => 'white',
	-text => 'Encrypt & Save',
	-command => sub {encrypt_save()}
	)->grid(
	-row => 11,
	-column =>2
	);
#  Check buton for checking if the input is encrypted
$is_encrypted = $mainwindow->Checkbutton(
	-background => 'white',
	-text => 'Encrypted File',
	-onvalue => 'Red',
	-offvalue => '',
	-command => sub {checkbutton_handle()}
	)->grid(
	-row => 10,
	-column =>0
	);

#Entry ---------------------------------------------------------------------------
#  Device selection menu
$drop_down_menu = $mainwindow->Optionmenu(	
	-width => '10',
	-background => 'white',
	-options => [options()],
	-command => sub { $device = shift;},
	#print "Device selectedis :  ", $device, "\n" },
	)->grid(
	-row => 1,
	-column => 1,
	);
#  Input file Entry
$input_file_entry = $mainwindow->Entry(
	-background => 'white',
	-width => 10,
	-textvariable => \$input_file
	)->grid(
	-row => 3,
	-column =>1
	);
#  Encryption key input entry
$input_key = $mainwindow->Entry(
	-background => 'white',
	-width => 10,
	-textvariable => \$passcode
	)->grid(
	-row => 5,
	-column =>1
	);
#  Start address input entry
$start_address_entry = $mainwindow->Entry(
	-background => 'white',
	-width => 10,
	-textvariable => \$start_address
	)->grid(
	-row => 9,
	-column =>1
	);
MainLoop;
#**************************************************************************************** Main GUI section Ends **********************************************************************

#*************************************************************************************** Functionality and Event responses ***********************************************************
#===  FUNCTION  ================================================================
#         NAME:  option
#      PURPOSE:  To get the list of available ttyACM devices 
#   PARAMETERS:  None
#      RETURNS:  List of available devices
#  DESCRIPTION:  Extract the ttyacm devices available in \dev directory by using grep
#       THROWS:  no exceptions
#     COMMENTS:  none
#     SEE ALSO:  n/a
#===============================================================================
sub options {
	my @option;
	
	if ($^O eq "MSWin32"){
		my $windows_com = `mode | findstr COM`;
		@option = ($windows_com=~ m/[COM\d+]+/g);
	}
	if ($^O eq "linux"){
		@option = `ls /dev | grep ttyACM`;
	}
	print "Available ports are: @option\n";
	chomp(@option);
	return @option;
}
#===  FUNCTION  ================================================================
#         NAME:  serial_port_init
#      PURPOSE:  to initialise the ttyACM port selected
#   PARAMETERS:  none
#      RETURNS:  none
#  DESCRIPTION:  Uses the Device::SerialPort module to initialise the ttyACM port and set necessary variables like baudrate
#       THROWS:  no exceptions
#     COMMENTS:  none
#     SEE ALSO:  n/a
#===============================================================================
sub serial_port_init{
	my $port_address = '';
	chomp($device);
	#print "$device\n";
	
	if ($^O eq "MSWin32"){
		$port_address = $device;
		$port = new  Win32::SerialPort ($port_address);
			die "Can't open $port_address: $!" if ! defined $port;
	}
	if ($^O eq "linux"){
		$port_address = '/dev/'.$device;
		$port = new  Device::SerialPort ($port_address);
				die "Can't open /dev/ttyACM0: $!" if ! defined $port;
	}

	$port->error_msg(1);
	$port->user_msg(1);
	$port->baudrate(115200);
	$port->databits(8);
	$port->handshake("none");
	$port->parity("none");
	$port->stopbits(1);
	$port->write_settings;
}
#===  FUNCTION  ================================================================
#         NAME:  send_packet
#      PURPOSE:  Sends the packets over the communication port
#   PARAMETERS:  Packet to be sent
#      RETURNS:  None
#  DESCRIPTION:  Recieves the packets from other functions pack it as hex and send it over the com port
#       THROWS:  no exceptions
#     COMMENTS:  none
#     SEE ALSO:  serial_port_init(),program(),encrypt_program()
#===============================================================================
sub send_packet {
	my $packet = shift @_;
	#my $header_packet = substr($packet,0,4); 
	#print "packet formed is $packet\n"; 
	$packet = pack("H*",$packet);
	my $count_out = $port->write($packet);
	warn "write failed\n" unless $count_out;
	warn "write incomplete\n" if $count_out != length($packet);
	#print " write success\n"; 
}
#===  FUNCTION  ================================================================
#         NAME:  timeout_erase
#      PURPOSE:  
#   PARAMETERS:  ????
#      RETURNS:  ????
#  DESCRIPTION:  ????
#       THROWS:  no exceptions
#     COMMENTS:  none
#     SEE ALSO:  n/a
#===============================================================================
sub timeout_erase{
	my  $answer = $mainwindow->Dialog(-title => 'Please Reply',
   -text => 'Operation failed!!! Check COM port, Device and Try Erasing again', 
   -default_button => 'OK', -buttons => [ 'OK'],
   -bitmap => 'question' )->Show( );
    die "timeout!\n";
}
#===  FUNCTION  ================================================================
#         NAME:  timeout
#      PURPOSE:  
#   PARAMETERS:  ????
#      RETURNS:  ????
#  DESCRIPTION:  ????
#       THROWS:  no exceptions
#     COMMENTS:  none
#     SEE ALSO:  n/a
#===============================================================================
sub timeout{
	my	$answer = $mainwindow->Dialog(-title => 'Please Reply', 
   -text => 'Operation failed!!! Check COM port, Device and Try Erasing again', 
   -default_button => 'OK', -buttons => [ 'OK'], 
   -bitmap => 'question' )->Show( );
	die "timeout!\n";
}
#===  FUNCTION  ================================================================
#         NAME:  recieve_response
#      PURPOSE:  
#   PARAMETERS:  ????
#      RETURNS:  ????
#  DESCRIPTION:  ????
#       THROWS:  no exceptions
#     COMMENTS:  none
#     SEE ALSO:  n/a
#===============================================================================
sub receive_response{
	my $data = '';
	my $temp = '';
	my $count_in = 0;
	my $total_in = 0;

	#print "Receiving....\n";
	local $SIG{ALRM} = sub {timeout_erase()};
	alarm (18);
	while(! ($total_in == 3)) {
		( $count_in, $temp ) = $port->read(3);
		$data = $data.$temp;
		$total_in = $total_in + $count_in;
		#print "received byte = $total_in\n";
    }
	alarm(0);

	my $received_hex = $data;
	$data  =~ s/(.)/sprintf("%02X",ord($1))/eg;
	#print("received_response = $data\n");
	return $received_hex;
}
#===  FUNCTION  ================================================================
#         NAME:  receive_response_program
#      PURPOSE:  
#   PARAMETERS:  ????
#      RETURNS:  ????
#  DESCRIPTION:  ????
#       THROWS:  no exceptions
#     COMMENTS:  none
#     SEE ALSO:  n/a
#===============================================================================
sub receive_response_program{
	my $data = '';
	my $temp = '';
	my $count_in = 0;
	my $total_in = 0;

	#print "Receiving....\n";
	local $SIG{ALRM} = sub {timeout()};
	alarm(3);
	while(! ($total_in == 3)) {
		( $count_in, $temp ) = $port->read(3);
		$data = $data.$temp;
		$total_in = $total_in + $count_in;
		#   print "recieved byte = $total_in\n";
	}
	alarm(0);

	my $received_hex = $data;
	$data  =~ s/(.)/sprintf("%02X",ord($1))/eg;
	#print("received_response = $data\n");
	return $received_hex;
}
#===  FUNCTION  ================================================================
#         NAME:  send_key
#      PURPOSE:  sends the encryption key to the device
#   PARAMETERS:  none
#      RETURNS:  none
#  DESCRIPTION:  Sends the packet that includes key used for encryption to the device
#       THROWS:  no exceptions
#     COMMENTS:  none
#     SEE ALSO:  n/a
#===============================================================================
sub send_passcode {
	$form_packet = ($header.$set_passcode.$passcode);
	send_packet ($form_packet);
}
#===  FUNCTION  ================================================================
#         NAME:  program
#      PURPOSE:  this function is initiated when the program button is pressed 
#   PARAMETERS:  none
#      RETURNS:  none
#  DESCRIPTION:  Responsible for forming packets.Programming includes the following step:
#				1) check if all the basic informations are availableie input file device etc.If not return and print error
#  				2) Initialise comport
#  				3) send open_port packet
#  				4) send key and initialisation vector if applicable
#  				5) send the data to be programmed
#  				6) close the comport
#       THROWS:  no exceptions
#     COMMENTS:  none
#     SEE ALSO:  n/a
#===============================================================================
sub program {
	my $start = [gettimeofday()];

	$user_warning_variable = '';
	if($input_file eq ''){
		$user_warning_variable = 'No input file Selected';
		return;
	}

	if($device eq ''){
		$user_warning_variable = 'No COM port Selected';
		return;
	}

	if (!($is_erased)){
		#print "flash not erased erase it first\n";
		$user_warning_variable = "Erase Command is not Sent, Please press Erase Button";
		return;
	}

	if($start_address eq ''){
		$user_warning_variable = 'Enter Application Start Address';
		return;
	}

	if ($encrypted_input){
		my $key_length = length($passcode);
		#print "key length = $key_length\n key = $key";
		if (!(length($passcode) == 4)){
			$user_warning_variable = 'Enter 4 bytes of Passcode';
			return;
		}
	}
	
	serial_port_init();
	my $current_address = $start_address;
	$form_packet = ($header.$open);
	send_packet ($form_packet);
	$receive_response_value = receive_response();
	if(!($receive_response_value eq $success_open)){
		#print "Error open\n";
		return;
	}

	my $encrypted_normal = $normal_data;
	if ($encrypted_input){
		#$passcode = unpack("H*",$passcode);
#		print "$passcode\n";
		send_passcode();
		#$passcode = pack("H*",$passcode);
		$receive_response_value = receive_response();
		if(!($receive_response_value eq $success_set_key)){
			#print "Error passcode\n";
			return;
  	 	}
		$encrypted_normal = $encrypted_data;
	}
	else{
		process_file();
	}
	
	#print "$input_file\n";
	open(IN, "< $input_file");
	binmode(IN);
	my $ofh = select IN;
	$| = 1;
	select $ofh;
	while (read(IN,$b,$page_size)) {
		$flash_data = $b;
		my $n = length($b);
		$byte_count = $n + $byte_count;
		my $s = 2*$n;
		
		#print "flash data = $flash_data \n";
		$flash_data = unpack("H$s", $b);
		#print "flash data = $flash_data \n";
		#$flash_data = pack("H*",$flash_data);
		
		my $address_length = length($current_address);
		$current_address = ('0'x(8-$address_length)).$current_address;
		
		my @split_packet = qw//;
		$split_packet[1] = substr ($flash_data,512,1024); 
		$split_packet[0] = substr ($flash_data,0,512);
		#print "First half = $split_packet[0]\n";
		#print "second half = $split_packet[1]\n";
		$form_packet = ($header.$program.$current_address.$encrypted_normal.$split_packet[1]);
		
		$is_erased = 0;
		send_packet ($form_packet);
		$receive_response_value = receive_response_program();
		if(!($receive_response_value eq $success_program)){
			#print "Error program\n";
			return;
	    }

		$form_packet = ($header.$program_2.$current_address.$encrypted_normal.$split_packet[0]);
        send_packet ($form_packet);
		$receive_response_value = receive_response_program();
		if(!($receive_response_value eq $success_program_2)){
		#print "Error program_2\n";
	    return;
	    }
		$current_address = hex($current_address) + $page_size;
		$current_address = sprintf("%x",$current_address);
		#print "first page sent\n";
		#print "$current_address\n";
	}
	my $timeconsumed = tv_interval($start)*1000;
	print "timeconsumed = $timeconsumed\n";
	close(IN);

    $form_packet = ($header.$reset);
    send_packet ($form_packet);
	$port->close;
	$user_warning_variable = 'File Programming Completed';
	
	sleep(1);
	$drop_down_menu->configure(-options=>[options()]);
	$device = '';
}
#===  FUNCTION  ================================================================
#         NAME:  enter_bootloader
#      PURPOSE:  Initiated when the erase button is pressed
#   PARAMETERS:  none
#      RETURNS:  none
#  DESCRIPTION:  1)Check if basic information is available ie comport.
#  				 2)Initialise comport
#  				 3)send open_port packet
#  				 4)send erase command
#  				 5)close the comport
#       THROWS:  no exceptions
#     COMMENTS:  none
#     SEE ALSO:  n/a
#===============================================================================
sub enter_bootloader{
	$drop_down_menu->configure(-options=>[options()]);

	$user_warning_variable = '';
	if($device eq ''){
		$user_warning_variable = 'No COM port Selected';
		return;
	}

	serial_port_init();

	$form_packet = ($header.$query_mode);
	send_packet ($form_packet);
	$receive_response_value = receive_response();
	
	if(($receive_response_value eq $is_bootloader)){
		$user_warning_variable = 'Already in Bootloader';
		$port->close;
		return;
	}
	elsif(($receive_response_value eq $is_application)){
		$form_packet = ($header.$open);
		send_packet ($form_packet);
		$receive_response_value = receive_response();
		if(!($receive_response_value eq $success_open_application)){
			$port->close;
			return;
		}
		
		$form_packet = ($header.$reset);
		send_packet ($form_packet);
		options();
		$port->close;
		sleep(1);
		$drop_down_menu->configure(-options=>[options()]);
		$device = '';
	}
	else
	{
		$user_warning_variable = 'Failed Response... Try again';
		$port->close;
		return;
	}
}
#===  FUNCTION  ================================================================
#         NAME:  erase
#      PURPOSE:  
#   PARAMETERS:  ????
#      RETURNS:  ????
#  DESCRIPTION:  ????
#       THROWS:  no exceptions
#     COMMENTS:  none
#     SEE ALSO:  n/a
#===============================================================================
sub erase {
	my $start = [gettimeofday()];
	$drop_down_menu->configure(-options=>[options()]);

	$user_warning_variable = '';
	if($device eq ''){
		$user_warning_variable = 'No COM port Selected';
		return;
	}

	serial_port_init();
	
	$form_packet = ($header.$query_mode);
    send_packet ($form_packet);
    $receive_response_value = receive_response();
    if(!($receive_response_value eq $is_bootloader)){
	   # print "not in application mode press enterbootloader first\n";
	   # $form_packet = ($header.$open);
	   # send_packet ($form_packet);
	   # $receive_response_value = receive_response();
	   #  if(!($receive_response_value eq $success_open_application)){
	   #  print "Error\n";
	   # return;
	   # }
	   $user_warning_variable =  "Not in Bootloader mode, Press Enter Bootloader";
	   return;
   }
   
	$form_packet = ($header.$erase);
	send_packet ($form_packet);
	$receive_response_value = receive_response();
	if(!($receive_response_value eq $success_erase)){
		$user_warning_variable = 'Erase Failed... Please Retry';
		return;
    }
	$user_warning_variable = 'Erase Completed';
	
	my $timeconsumed = tv_interval($start)*1000;
    print "timeconsumed = $timeconsumed\n";
	$port->close;
	$is_erased = 1;
}
#===  FUNCTION  ================================================================
#         NAME:  open_file
#      PURPOSE:  Initiated when the browse button is pressed
#   PARAMETERS:  input_file_type
#      RETURNS:  input_file
#  DESCRIPTION:  opens the browse window and returns the path of the file selected
#       THROWS:  no exceptions
#     COMMENTS:  none
#     SEE ALSO:  n/a
#===============================================================================
sub open_file{
	$input_file = $mainwindow->getOpenFile(
		-filetypes => $output_file_type,
		-initialfile => ".bin"
		);
	#print $input_file;
}
#===  FUNCTION  ================================================================
#         NAME:  process_file
#      PURPOSE:  To stuff the input file so that its size is a multiple of 512 bytes(PageSize)
#   PARAMETERS:  None
#      RETURNS:  None
#  DESCRIPTION:  Opens the file selected in the input file find the value of bytes to be stuffed and appends that much byte of 'ff'
#       THROWS:  no exceptions
#     COMMENTS:  none
#     SEE ALSO:  n/a
#===============================================================================
sub process_file{
	my $footer = 'ff';
	my $endpad = $footer x 44;
	my $header = '80';
	my $pad = '00' x 55;
	my $document = '';
	my $fh;
	my $in;
	my $truncate_size;
	my $filesize = -s $input_file;
	$truncate_size = $filesize - 128;

	open $fh, ">>" ,$input_file;
	#seek $fh, $offset, 2;
	truncate $fh,$truncate_size;
	close ($fh);
	unless(open $in,$input_file) {
		warn "$0 $!";
		next;
	}

	binmode($in);
	my $sha1_out = Digest::SHA1->new;
	$sha1_out->addfile($in);
	my $sha1 = $sha1_out->hexdigest;
	#print "$sha1\n";
	close($in);

	#open $fh, ">>try.bin";
	$filesize = -s $input_file;
	#print "$filesize\n";
	$filesize = $filesize * 8;
	$filesize = sprintf("%x",$filesize);
	my $len = length($filesize);
	#print "$len\n";
	$filesize = ('0' x (16-$len)).$filesize; 
	my $last = $header.$pad.$filesize.$sha1.$endpad;
	#print "$last\n";
	my $length_pad =  length($last);
	#print "$length_pad\n";
	$last = pack("H*",$last);
	open $fh, ">>" , $input_file;
	binmode($fh);
	print ($fh $last);
	close($fh);
}
#===  FUNCTION  ================================================================
#         NAME:  encrypt_init
#      PURPOSE:  
#   PARAMETERS:  ????
#      RETURNS:  ????
#  DESCRIPTION:  ????
#       THROWS:  no exceptions
#     COMMENTS:  none
#     SEE ALSO:  n/a
#===============================================================================
sub encrypt_init{
	my $iv_index = 0;
	my $key_index = 0;

	$key_index = substr($passcode, 0 , 2);
	$iv_index = substr($passcode, 2 , 4);
	#print "key = $key[$key_index]\n";
	#print "iv = $iv[$iv_index]\n";
	$cipher = Crypt::CBC->new(
		-key       => pack("H*",$key[$key_index]),
		-keysize => '16',
		-keylength => '128',
		-header    => 'none',
		-literal_key => 1,
		-iv    => pack("H*",$iv[$iv_index]),
		-cipher    => "Crypt::OpenSSL::AES",
		); 
}
#===  FUNCTION  ================================================================
#         NAME:  encrypt
#      PURPOSE:  Initialise the cipher to be used to encrypt the device
#   PARAMETERS:  512 bytes of flash data
#      RETURNS:  512 bytes of encrypted data
#  DESCRIPTION:  Uses the Crypt::CBC and Crypt::OpenSSL::AES to form the cipher and encrypt the data
#       THROWS:  no exceptions
#     COMMENTS:  none
#     SEE ALSO:  n/a
#===============================================================================
sub encrypt {
	my $b = shift @_; 
	my $n = length($b);
    my $s = 2*$n;

    my $raw_data = unpack("H$s", $b);
    $raw_data = pack("H*",$raw_data);

	my $encrypted = $cipher->encrypt_hex($raw_data);
    $encrypted = substr $encrypted,0,($page_size*2);

	return $encrypted;
}
#===  FUNCTION  ================================================================
#         NAME:  checkbutton_handle
#      PURPOSE:  called when the check button is clicked
#   PARAMETERS:  none
#      RETURNS:  none
#  DESCRIPTION:  checks the status of checkbutton and sets the value of encrypted_button accordingly
#       THROWS:  no exceptions
#     COMMENTS:  none
#     SEE ALSO:  n/a
#===============================================================================
sub checkbutton_handle{
	#print "Encrypted input Clicked!\n";
	$encrypted_input = ($encrypted_input+1)%2;
	#print "Value of encrypted_input = $encrypted_input\n"
	if ($encrypted_input){
		$user_warning_variable = 'Input File will be treated as Encrypted';
	}
	else{
		$user_warning_variable = 'Input File will be treated as Normal';
	}
}
#===  FUNCTION  ================================================================
#         NAME:  encrypt_save
#      PURPOSE:  Encrypts the data and save it into the file specified by the user
#   PARAMETERS:  none
#      RETURNS:  none
#  DESCRIPTION:  Encrypts data and saves it
#       THROWS:  no exceptions
#     COMMENTS:  none
#     SEE ALSO:  n/a
#===============================================================================
sub encrypt_save{
	$user_warning_variable = '';
	if($input_file eq ''){
		$user_warning_variable = 'No Input File Selected';
		return;
	}
	if (length($passcode) lt 4){
		$user_warning_variable = 'Enter 4 bytes of Passcode';
		return;
	} 

	process_file();
	encrypt_init();

	my $file_data = '';
	my $output_data = '';
	open(IN, "< $input_file");
	binmode(IN);
	while (read(IN,$b,$page_size)) {
		$file_data = $b;
		$file_data = unpack("H*", $b);
		#print "Data before Encryption = $file_data \n";
		$file_data = encrypt($b);
		#print "Data after Encryption $file_data\n";
		$output_data = $output_data.$file_data;
	}
	
	#print ("Encryption Completed\n");
	$output_file = $mainwindow->getSaveFile(
		-filetypes => $output_file_type,
		-initialfile => "encrypted.bin"
		);

	$output_data = pack("H*",$output_data);
	open(OUT, "> $output_file");
	binmode(OUT);
	print (OUT $output_data);
	close(OUT);
	$user_warning_variable = 'File Encryption Completed and Saved';
}