#ifndef XIL_PRINTF_H
#define XIL_PRINTF_H

#include <stdio.h>

#define xil_printf printf


#endif	/* end of protection macro */
