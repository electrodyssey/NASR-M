# Test scripts and other host software

Note: Assumes Xilinx XDMA driver is installed. XDMA driver is available here: https://github.com/Xilinx/dma_ip_drivers/tree/master/XDMA/linux-kernel

Scripts are provided to tests DDR, read voltages and temperatures.

Each script takes arguments run with -help flag



